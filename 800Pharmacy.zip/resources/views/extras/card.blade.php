<div class="col-sm-6">
    <div class="business-card">
        <div class="media">
            <div class="media-left">
                <img class="media-object img-circle profile-img" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png">
            </div>
            <div class="media-body">
                <h2 class="media-heading">Daniel</h2>
                <div class="job">CEO</div>
                <div class="mail"><a href="mailto:daniel@bla.ch">daniel@bla.ch</a> </div>
            </div>
        </div>
    </div>
</div>