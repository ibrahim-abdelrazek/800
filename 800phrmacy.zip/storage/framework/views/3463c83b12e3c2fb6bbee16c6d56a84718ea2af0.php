

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, [  'class' => 'form-control']); ?>

</div>


<!--  Status -->
<div class="form-group col-sm-8 col-sm-offset-2" id='status'>
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::select('status', ['1' => 'active' , '0' => 'not active'] , null, [  'class' => 'form-control']); ?>

</div>



<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('partnertypes.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








