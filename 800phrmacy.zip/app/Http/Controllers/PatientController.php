<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Patient;
use Illuminate\Support\Facades\Auth;


class PatientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index()
    {
        //
       if(Auth::user()->user_group_id == 1 ){

       $patients = Patient::get();

        }elseif (Auth::user()->user_group_id == 2 ) {

        $patients = Patient::where('partner_id',Auth::user()->partner_id)->get();

        } else{

        $patients = Patient::where('user_id',Auth::user()->id)->get();
        }

        return view('patients.index')->with('patients' , $patients );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('patients.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
       'first_name' => 'required|max:45|min:2',
        'last_name' => 'required|max:45|min:2',
        'date' => 'required',
        'gender'=>'required',
        'contact_number'=> 'required',
        'email'=>'required|unique:Patients',
        'insurance_card_details'=>'required',
        'emirates_id_details'=>'required',
        'notes'=>'required',
        'address'=>'',
        'partner_id'=>'required'



        ]);
        // $address1=$request->input('');
        //$address2=$request->input('');
        //$input->address=$address1 . $address2; 

/*'id','first_name', 'last_name', 'date','gender','contact_number','email','insurance_card_details','emirates_id_details','notes','address','partner_id','user_id*/
       /*$new= new Patient();
        $new->first_name =$request->input('first_name');
        $new->last_name =$request->input('last_name');
        $new->date =$request->input('date');
        $new->gender =$request->input('gender');
        $new->contact_number =$request->input('contact_number');
        $new->email =$request->input('email');
        $new->insurance_card_details =$request->input('insurance_card_details');
        $new->emirates_id_details =$request->input('emirates_id_details');
        $new->notes =$request->input('notes');
        $address1=$request->input('addresscompany');
        $address2=$request->input('addressbuilding');
        $address3=$request->input('addressoffice');
        $new->address='company name : '.$address1 .'building: '. $address2 .'office: '. $address3;
        $new->partner_id =$request->input('partner_id');
        $new->user_id =$request->input('user_id');
        $new->save();*/

// check  value 6, 4, 5
        $patients = Patient::create([
            'first_name' => request('first_name'),
            'last_name' => request('last_name'),
            'date' => request('date'),
            'gender' => request('gender'),
            'contact_number' => request('contact_number'),
            'email' => request('email'),
            'insurance_card_details' => request('insurance_card_details'),
            'emirates_id_details' => request('emirates_id_details'),
            'notes' => request('notes'),
            'address' =>request('addresscity').','.
            request('addressarea').','.
            request('addressstreet').','.
            request('addresscompany') .','.
             request('addressbuilding').',' .
             request('addressoffice').',' .
             request('villanumber').','. 
             request('buildingname').','.
              request('apartmentnumber'),
            'partner_id' => request('partner_id'),
            'user_id' => request('user_id')

        ]);

        return redirect(route('patients.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
         $patient = Patient::find($id);

        if(empty($patient)){
            return redirect(route('patients.index'));
        }

        return view('patients.show')->with('patient' , $patient );

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $patient = Patient::find($id);

        if(empty($patient)){
            return redirect(route('patients.index'));
        }

        return view('patients.edit')->with('patient' , $patient );
    }
    

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, $id)
    {
        //
          $request->validate([
       'first_name' => 'required|max:45|min:2',
        'last_name' => 'required|max:45|min:2',
        'date' => 'required',
        'gender'=>'required',
        'contact_number'=> 'required',
        'email'=>'required|unique:Patients',
        'insurance_card_details'=>'required',
        'emirates_id_details'=>'required',
        'notes'=>'required',
        'address'=>'',
        'partner_id'=>'required'



        ]); 

         $patient = Patient::find($id);

        if(empty($patient)){
            return redirect(route('patients.index'));
        }

        $patient->update([
            'first_name' => request('first_name'),
            'last_name' => request('last_name'),
            'date' => request('date'),
            'gender' => request('gender'),
            'contact_number' => request('contact_number'),
            'email' => request('email'),
            'insurance_card_details' => request('insurance_card_details'),
            'emirates_id_details' => request('emirates_id_details'),
            'notes' => request('notes'),
            'address' =>request('addresscity').','.
            request('addressarea').','.
            request('addressstreet').','.
            request('addresscompany') .','.
             request('addressbuilding').',' .
             request('addressoffice').',' .
             request('villanumber').','. 
             request('buildingname').','.
              request('apartmentnumber'),
            'partner_id' => request('partner_id'),
            'user_id' => request('user_id')

        ]);
        /*$new= new Patient();
        $new->first_name =$request->input('first_name');
        $new->last_name =$request->input('last_name');
        $new->date =$request->input('date');
        $new->gender =$request->input('gender');
        $new->contact_number =$request->input('contact_number');
        $new->email =$request->input('email');
        $new->insurance_card_details =$request->input('insurance_card_details');
        $new->emirates_id_details =$request->input('emirates_id_details');
        $new->notes =$request->input('notes');
        $address1=$request->input('addresscompany');
        $address2=$request->input('addressbuilding');
        $address3=$request->input('addressoffice');
        $new->address='company name :'. $address1 .'building:'. $address2 .'office:'. $address3;
        $new->partner_id =$request->input('partner_id');
        $new->user_id =$request->input('user_id');
        $new->save();*/

        return redirect(route('patients.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
         $patient = Patient::find($id);
        if(empty($patient)){
            return redirect(route('patients.index'));
        }
        $patient->delete($id);
        return redirect(route('patients.index'));
    }
}
