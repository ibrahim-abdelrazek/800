<div class="row">
    <div class="col-lg-12 ks-panels-column-section">
        <div class="card">
            <div class="card-block">
                <h5 class="card-title">Create new Partner Type</h5>

                    <?php echo Form::open(['route' => 'partnertypes.store']); ?>


                    <?php echo $__env->make('partnertypes.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::close(); ?></div>
        </div>

    </div>
</div>