
<?php $__env->startPush('customcss'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('libs/jquery-confirm/jquery-confirm.min.css')); ?>"> <!-- original -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/libs/jquery-confirm/jquery.confirm.min.css')); ?>"> <!-- original -->

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="ks-page-header">
        <section class="ks-title">
            <h3>User Groups</h3>
        </section>
    </div>
    <div class="ks-page-content">
        <div class="ks-page-content-body">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 col-sm-12 col-sm-12">

                        <?php echo $__env->make('usergroups.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="col-lg-6 col-sm-12 col-sm-12">
                        <?php echo $__env->make('usergroups.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('customjs'); ?>
    <script src="<?php echo e(asset('libs/jquery-confirm/jquery-confirm.min.js')); ?>"></script>
    <script type="application/javascript">
        // asynchronous content
        (function ($) {
            $(document).ready(function () {
                $('.show-details').on('click', function () {
                    $.dialog({
                        title: 'User Group',
                        content: 'url:' + "<?php echo e(url('usergroups')); ?>/" + $(this).attr('data-id'),
                        animation: 'zoom',
                        columnClass: 'medium',
                        closeAnimation: 'scale',
                        backgroundDismiss: true
                    });
                });

            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>