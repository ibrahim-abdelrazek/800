<?php $__env->startSection('login'); ?>
    <div class="ks-page">
        <div class="ks-page-header">
            <a href="#" class="ks-logo">800Pharmacy</a>
        </div>
        <div class="ks-page-content">
            <div class="ks-logo">800Pharmacy</div>

            <div class="card panel panel-default ks-light ks-panel ks-login">
                <div class="card-block">
                    <form action="<?php echo e(route('login')); ?>"  method="POST" class="form-container">
                        <?php echo e(csrf_field()); ?>

                        <h4 class="ks-header">Login</h4>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <div class="input-icon icon-left icon-lg icon-color-primary">
                                <input name="email" type="text" class="form-control" placeholder="Email">
                                <span class="icon-addon">
                                <span class="la la-at"></span>

                            </span>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <div class="input-icon icon-left icon-lg icon-color-primary">
                                <input name="password" type="password" class="form-control" placeholder="Password">
                                <span class="icon-addon">
                                <span class="la la-key"></span>
                            </span>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                        </div>
                        <div class="ks-text-center">
                            <a href="<?php echo e(route('password.request')); ?>">Forgot your password?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="ks-footer">
            <span class="ks-copyright">&copy; <?php echo e(date('Y')); ?> 800Pharmacy</span>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>