@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3> Edit Partner Types </h3>
                    </div>

                    <div class="panel-body">

                        {!! Form::model($profile, ['route' => ['profile.update', $profile['id']], 'method' => 'patch']) !!}

                        <!--  Name -->
                            <div class="form-group col-sm-8 col-sm-offset-2" id='name'>
                                {!! Form::label('name', 'Name:') !!}
                                {!! Form::text('name', null, [  'class' => 'form-control' , 'required']) !!}
                            </div>

                            <!--  Username -->
                            <div class="form-group col-sm-8 col-sm-offset-2" >
                                {!! Form::label('username', 'Username:') !!}
                                {!! Form::text('username', null, [  'class' => 'form-control' , 'required']) !!}
                            </div>

                            <!--  Email -->
                            <div class="form-group col-sm-8 col-sm-offset-2" >
                                {!! Form::label('email', 'Email:') !!}
                                {!! Form::email('email', null, [  'class' => 'form-control' , 'required']) !!}
                            </div>
                            <!--  password -->
                            <div class="form-group col-sm-8 col-sm-offset-2" >
                                {!! Form::label('password', 'password:') !!}
                                {!! Form::password('password', [  'class' => 'form-control' ]) !!}
                            </div>

                        @if(isset($profile['location']))
                            <!--  location -->
                                <div class="form-group col-sm-8 col-sm-offset-2" >
                                    {!! Form::label('location', 'Location:') !!}
                                    {!! Form::text('location', null, [  'class' => 'form-control' ]) !!}
                                </div>
                        @endif

                        {!! Form::hidden('partner_id', null ) !!}





                            <!-- Submit Field -->
                            <div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

                                {!! Form::submit('Save', ['class' => 'btn btn-danger']) !!}
                                <a href="{!! route('profile.index') !!} " class="btn btn-default" > Cancel</a>
                            </div>


                            {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
