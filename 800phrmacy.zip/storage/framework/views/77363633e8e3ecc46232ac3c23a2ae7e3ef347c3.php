

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, [  'class' => 'form-control']); ?>

</div>


<!-- Officer Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('officer_name', 'Officer Name:'); ?>

    <?php echo Form::text('officer_name', null, [  'class' => 'form-control']); ?>

</div>

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('contact_number', 'Contact Number:'); ?>

    <?php echo Form::text('contact_number', null, [  'class' => 'form-control']); ?>

</div>

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('guest_room_number', 'Guest Room Number:'); ?>

    <?php echo Form::text('guest_room_number', null, [  'class' => 'form-control']); ?>

</div>

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('guest_first_name', 'Guest First Name:'); ?>

    <?php echo Form::text('guest_first_name', null, [  'class' => 'form-control']); ?>

</div>

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('guest_last_name', 'Guest Last Name:'); ?>

    <?php echo Form::text('guest_last_name', null, [  'class' => 'form-control']); ?>

</div>

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('items', 'Items:'); ?>

    <?php echo Form::text('items', null, [  'class' => 'form-control']); ?>

</div>

<?php echo Form::hidden('partner_id',Auth::user()->partner_id); ?>






<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('hotelguest.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








