<?php

namespace App\Http\Controllers;

use App\Notifications\OrderCreated;
use App\User;
use Illuminate\Http\Request;
use App\Order;
use Illuminate\Support\Facades\Auth;



class OrderController extends Controller
{


    public function index()
    {
        //
        if(Auth::user()->ableTo('view',Order::$model)) {

            if (Auth::user()->isAdmin()) {

                $orders = Order::get();

            } elseif (Auth::user()->user_group_id == 2) {

                $orders = Order::where('partner_id', Auth::user()->partner_id)->get();

            } else {

                $orders = Order::where('user_id', Auth::user()->id)->get();
            }

            return view('orders.index')->with('orders', $orders);
        }else {
            return view('extra.404');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if(Auth::user()->ableTo('add',Order::$model)) {

            return view('orders.create');
        }else {
            return view('extra.404');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        if(Auth::user()->ableTo('add',Order::$model)) {

            $this->validate($request, [
                'prescription' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'insurance_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'insurance_text' => 'required|string|min:5',
                'notes' => 'required|string|min:5',

            ]);


            // Insurance Image
            $destinationPath = './upload/';
            $file = $request->file('insurance_image');

            $input['insurance_image'] = $file->getClientOriginalName();
            $input['insurance_image']  =  rand(10000000, 99999999)  . '_' .$input['insurance_image'] ;
            $file->move($destinationPath, $input['insurance_image']);

            // Prescription Image
            $file = $request->file('prescription');

            $input['prescription'] = $file->getClientOriginalName();
            $input['prescription']  =  rand(10000000, 99999999)  . '_' .$input['prescription'] ;
            $file->move($destinationPath, $input['prescription']);

            if ($request->has('partner_id')) {
                $order = $request->all();
            }else {
                if (Auth::user()->user_group_id == 2) {
                    $order = array_merge($request->all(), ['partner_id' => Auth::user()->partner_id]);
                } else {
                    $order = array_merge($request->all(), ['partner_id' => Auth::user()->partner_id]);
                    $order = array_merge($order, ['user_id' => Auth::user()->id]);
                }
            }
            if(Order::create($order))
                return redirect(route('orders.index'));

        }else {
            return view('extra.404');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        if(Auth::user()->ableTo('view',Order::$model)) {

            $order = Order::find($id);

            if (empty($order)) {
                return redirect(route('orders.index'));
            }

            return view('orders.show')->with('order', $order);
        }else{
            return view('extra.404');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if(Auth::user()->ableTo('edit',Order::$model)) {

            $order = Order::find($id);

            if (empty($order)) {
                return redirect(route('orders.index'));
            }

            return view('orders.edit')->with('order', $order);

        }else {
            return view('extra.404');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(Auth::user()->ableTo('edit',Order::$model)) {

            //|image|mimes:jpeg,png,jpg,gif,svg|max:2048
            $this->validate($request, [
                'prescription' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'insurance_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'insurance_text' => 'required',
                'notes' => 'required|string|min:5'
            ]);

            $order = Order::find($id);

            if (empty($order)) {
                return redirect(route('orders.index'));
            }
            if($request->hasFile('insurance_image')){
                $destinationPath = './upload/';
                $file = $request->file('insurance_image');

                $input['insurance_image'] = $file->getClientOriginalName();
                $input['insurance_image']  =  rand(0,10000000)  . '_' .$input['insurance_image'] ;
                $file->move($destinationPath, $file->getClientOriginalName());
            }
            if($request->hasFile('prescription')){
                $file = $request->file('prescription');

                $input['prescription'] = $file->getClientOriginalName();
                $input['prescription']  =  rand(10000000, 99999999)  . '_' .$input['prescription'] ;
                $file->move($destinationPath, $input['prescription']);
            }


            if ($request->has('partner_id')) {
                $order = $request->all();
            }else {
                if (Auth::user()->user_group_id == 2) {
                    $order = array_merge($request->all(), ['partner_id' => Auth::user()->partner_id]);
                } else {
                    $order = array_merge($request->all(), ['partner_id' => Auth::user()->partner_id]);
                    $order = array_merge($order, ['user_id' => Auth::user()->id]);
                }
            }
            $order->update($order);

            return redirect(route('orders.index'));
        }else {
            return view('extra.404');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(Auth::user()->ableTo('delete',Order::$model)) {

            $order = Order::find($id);
            if (empty($order)) {
                return redirect(route('orders.index'));
            }
            $order->delete($id);
            return redirect(route('orders.index'));
        }else {

            return view('extra.404');
        }
    }
}
