<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class=""> Sub-Users</h3>
                    </div>

                    <div class="panel-body">

                        <div class="show">
                            <span>Name: </span>
                            <span class="value" ><?php echo $usergroup->group_name; ?></span>
                        </div>
                        <br>

                        <?php
                            $data = unserialize($usergroup->action);
                            $models = ['doctor','patient', 'hotelguest' ,'nurse','order', 'product', 'transaction'] ;
                             $actions = ['view', 'add' ,'edit' ,'delete'];
                             $dataa =array();
                             foreach ($data as $k => $v){
                                 $result = str_split($v);
                                 $action= array();
                                  $action[$actions[0]]= $result[0];
                                  $action[$actions[1]]= $result[1];
                                  $action[$actions[2]]= $result[2];
                                  $action[$actions[3]]= $result[3];

                                 $dataa[$k] = $action;

                             }

                        ?>

                        <div class="table text-center">
                            <table class="table table-responsive" >
                                <thead>
                                <th>Model</th>
                                <?php

                                    foreach ($actions  as $action ){

                                        echo "<th>" . $action ."</th>";
                                    }
                                ?>
                                </thead>

                                <tbody>
                                <?php
                                    foreach ($dataa as $k => $data){
                                    echo "<tr>";
                                    echo "<td>". $k. "</td>";

                                    foreach ($data as $d){
                                ?>
                                    <?php
                                        if($d == 1 ){
                                            echo "<td>&#10004</td>";
                                        }else{
                                         echo "<td> &#10006 </td> ";
                                        }
                                    }
                                    ?>

                                    <?php
                                        echo "</tr>";
                                    }

                                    ?>
                                    <tr>

                                    </tr>
                                </tbody>
                            </table>
                        </div>


                      




                        <br>
                        <a href="<?php echo route('usergroups.index'); ?>" class="btn btn-default pull-right">Back</a>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>