<table class="table table-bordered text-light stacktable large-only">
    <thead class="thead-default">
    <tr>
        <th width="1">#</th>
        <th>Name</th>
        <th>Speciality</th>
        <th>Contact</th>
        <th>Actions</th>

    </tr>
    </thead>
    <tbody>
    <?php ($i = 1); ?>
    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td scope="row"><?php echo e($i); ?></td>
            <td><?php echo e($doctor->name); ?></td>
            <td><?php echo e($doctor->specialty); ?></td>
            <td><?php echo e($doctor->contact_details); ?></td>
            <td>
                <?php echo Form::open(['route' => ['doctors.destroy', $doctor->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo url('doctors/'. $doctor->id); ?>" class='btn btn-default btn-xs'>Show</a>

                    <a href="<?php echo e(URL::to('doctors/' . $doctor->id . '/edit')); ?>"
                       class='btn btn-default btn-xs'>Edit</a>
                    <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
        <?php ($i++); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>