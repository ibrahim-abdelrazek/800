<div class="table text-center">
   <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>No.</th>
        <th>Name</th>
        <th>location</th>
        <th>Partner Type</th>
        <th>Username</th>
        <th>Email</th>
        <th colspan="3">Action</th>
        </thead>
        <tbody>
        <?php
            $j =0 ;
        ?>
        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $j++ ;
            ?>
            <tr>
                <td><?php echo e($j); ?></td>
                <td><?php echo e($partner->name); ?></td>
                <td> <?php echo e($partner->location); ?></td>
                <td> <?php echo e($partner->partnerType->name); ?></td>
                <td> <?php echo e($partner->user->username); ?></td>
                <td><?php echo e($partner->user->email); ?></td>



                <td>
                    <?php echo Form::open(['route' => ['partners.destroy', $partner->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('partners.show', [$partner->id]); ?>" class='btn btn-default btn-xs'>Show</a>
                        <a href="<?php echo route('partners.edit', [$partner->id]); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>