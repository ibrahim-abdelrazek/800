<div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    <?php endif; ?>
</div>
<!--  Name -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('name', 'Name:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::text('name', null, [  'placeholder'=>'Enter Doctor\'s name', 'class' => 'form-control']); ?>

    </div>
</div>

<!--  specialty -->
<div class="form-group row">
    <label for="default-input"
           class="col-sm-2 form-control-label"><?php echo Form::label('specialty', 'specialty:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::text('specialty', null, [  'placeholder'=>'Enter Doctor\'s Speciality', 'class' => 'form-control']); ?>

    </div>
</div>
<!--  contact -->
<div class="form-group row">
    <label for="default-input"
           class="col-sm-2 form-control-label"><?php echo Form::label('contact', 'Contact details:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::text('contact_details', null, [  'placeholder'=>'Enter Doctor\'s Contact details', 'class' => 'form-control']); ?>

    </div>
</div>

<!--  Partner -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('partner', 'partner'); ?></label>
    <div class="col-sm-10">
        <?php if(\App\Partner::count() > 0): ?>
            <?php echo Form::select('partner_id',App\Partner::pluck('name','id'),null,['class' => 'form-control']); ?>

        <?php else: ?>
            <p>You don't have added partners yet, Please <a href="<?php echo e(route('partners.index')); ?>"><b class="label-danger">Add
                        new Nurse</b></a></p>
        <?php endif; ?>
    </div>
</div>
<!-- End Partner -->

<!-- Nurse -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('partner', 'partner:'); ?></label>
    <div class="col-sm-10">
        <?php if(\App\Nurse::count() > 0): ?>
            <?php echo Form::select('nurse_id',App\Nurse::pluck('name','id'),null,['class' => 'form-control']); ?>

        <?php else: ?>
            <p>You don't have added nurses yet, Please <a href="<?php echo e(route('nurses.index')); ?>"><b class="label-danger">Add
                        new Nurse</b></a></p>
        <?php endif; ?>
    </div>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>
    <?php if(\App\Nurse::count() > 0 && \App\Partner::count() > 0): ?>
        <?php echo Form::submit('Save', ['class' => 'btn btn-large btn-success']); ?>

    <?php else: ?>
        <?php echo Form::submit('Save', ['disabled', 'class' => 'btn btn-large btn-success']); ?>

    <?php endif; ?>
</div>








