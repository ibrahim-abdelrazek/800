<table class="table table-bordered text-light stacktable large-only">
    <thead class="thead-default">
    <tr>
        <th width="1">#</th>
        <th>Name</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php ($i = 1); ?>
    <?php $__currentLoopData = $partnertypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partnertype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo $partnertype->name; ?></td>
            <td>
                <?php if($partnertype->status == 1): ?>
                    <span class="label label-success">Active</span>
                <?php else: ?>
                    <span class="label label-danger">Not Active</span>
                <?php endif; ?>
            </td>
            <td>
                <?php echo Form::open(['route' => ['partnertypes.destroy', $partnertype->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('partnertypes.edit', [$partnertype->id]); ?>" class="btn btn-default btn-xs">
                        <i class="la la-pencil-square-o" aria-hidden="true">Edit</i>
                    </a>
                    <?php echo Form::button('Delete', ['type' => 'submit', 'style'=>'cursor:pointer;', 'class' => 'btn btn-danger la la-trash btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
        <?php ($i++); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>