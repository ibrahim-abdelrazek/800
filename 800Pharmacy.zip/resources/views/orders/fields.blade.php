
<div>
                    @if($errors->any())
                       <div class="alert alert-danger">
                           <ul>
                            @foreach($errors->all() as $error)
                            <li>{{$error}}</li>
                            @endforeach

                           </ul>
                           </div>
                           @endif
                    </div>
<!--  prescription -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('prescription', 'prescription:') !!}
    {!! Form::text('prescription', null, [  'class' => 'form-control']) !!}
</div>


<!--  insurance_image -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('insurance_image', 'insurance image:') !!}
    {!! Form::file('insurance_image',null,  [  'class' => 'form-control']) !!}
</div>



<!--  insurance_text -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('insurance_text', 'insurance text:') !!}
    {!! Form::text('insurance_text',null, [  'class' => 'form-control']) !!}
</div>


<!-- notes -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('notest', 'notes:') !!}
    {!! Form::textarea('notes',null, [  'class' => 'form-control']) !!}
</div>


<!--  patient_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('patient', 'patient') !!}
   {!! form :: select ('patient_id',App\Patient::select(DB::raw("CONCAT(first_name,' ', last_name) AS full_name, id"))->pluck('full_name','id'),null,['class' => 'from-controller'])!!}
 
</div>


<!--  doctor_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('doctor', 'doctor') !!}
   {!! form :: select ('doctor_id',App\Doctor::pluck('name','id'),null,['class' => 'from-controller'])!!}
 
</div>



<!--  partner_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('partner', 'partner') !!}
   {!! form :: select ('partner_id',App\Partner::pluck('name','id'),null,['class' => 'from-controller'])!!}
 
</div>


<!--  product_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('product', 'product') !!}
   {!! form :: select ('product_id',App\Product::pluck('name','id'),null,['class' => 'from-controller'])!!}
 
</div>





<!-- user-id-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
{!! Form::hidden('user_id', Auth::user()->id ) !!}
</div>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    {!! Form::submit('Save', ['class' => 'btn btn-danger']) !!}
    <a href="{!! route('orders.index') !!} " class="btn btn-default" > Cancel</a>
</div>








