@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class=""> patient </h3>
                    </div>

                    <div class="panel-body">

                        <div class="show">
                            <span>first name: </span>
                            <span class="value" >{{ $patient->first_name }}.{{ $patient->last_name}}</span>
                        </div>

                        <div class="show">
                            <span> last name:</span>
                            <span class="value" >{{ $patient->last_name}}</span>
                        </div>
                        <div class="show">
                            <span>date: </span>
                            <span class="value" >{{ $patient->date }}</span>
                        </div>

                         <div class="show">
                            <span>gender: </span>
                            <span class="value" >{{ $patient->gender }}</span>
                        </div>

                        <div class="show">
                            <span>contact_number: </span>
                            <span class="value" >{{ $patient->contact_number }}</span>
                        </div>
                        <div class="show">
                            <span>email: </span>
                            <span class="value" >{{ $patient->email }}</span>
                            
                        </div>
                        <div class="show">
                            <span>insurance_card_details: </span>
                            <span class="value" >{{ $patient->insurance_card_details }}</span>
                            
                        </div>

                        <div class="show">
                            <span>notes: </span>
                            <span class="value" >{{ $patient->notes }}</span>
                        </div>


                        <div class="show">
                            <span> </span>
                            <!-- -->
                            @php $data=$patient->address;
                            $datas= explode(',',$data);
                            @$addressname='city: /area: /street: /company name: /building name: /office: /villa: /building name: /apartment number: ';
                            @$address=explode('/',$addressname);
                            @endphp
                            
                            
                            @for($i=0;$i<=2;$i++)

                        <span class="value" >{{$address[$i]}} {{$datas[$i]}}<br/></span>
                             <!--<span class="value" >{{$datas[0]}}<br/></span>
                             <span class="value" >{{$datas[1]}}<br/></span>
                             <span class="value" >{{$datas[2]}}<br/></span>-->
                             @endfor


                             <!--check company name/building name(office)/office -->

                             
                             @if($datas[3] != null && $datas[4] != null && $datas[5] != null)
                            
                            @for($i=3;$i<=5;$i++)

                        <span class="value" >{{$address[$i]}} {{$datas[$i]}}<br/></span>
                            
                             @endfor

                             @endif
                             <!--check villa -->
                             @if($datas[6] != null)
                             <span class="value" >{{$address[6]}} {{$datas[6]}}<br/></span>
                             @endif

                             <!--check buildng name/apartment -->
                              @if($datas[7] != null && $datas[8] != null )
                            
                            @for($i=7;$i<=8;$i++)

                        <span class="value" >{{$address[$i]}} {{$datas[$i]}}<br/></span>
                            
                             @endfor

                             @endif
                        </div>
                        <div class="show">
                            <span>created at </span>
                            <span class="value" >{{ $patient->created_at }}</span>
                        </div>
                        <div class="show">
                            <span>updated at </span>
                            <span class="value" >{{ $patient->updated_at }}</span>
                        </div>
                        


                        <br>
                        <a href="{!! route('patients.index') !!}" class="btn btn-default pull-right">Back</a>



                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
