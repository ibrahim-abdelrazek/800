@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3> Edit order </h3>
                    </div>

                    <div class="panel-body">

                        {!! Form::model($order, ['route' => ['orders.update', $order->id], 'method' => 'patch','files' =>true]) !!}


                        @include('orders.fields')

                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@push('customjs')
    <script type="text/javascript">
        $(document).ready(function() {

          /*  $('select[name="partner_id"]').prepend("<option value='' disabled selected='selected'>--Partner--</option>");
            $('select[name="patient_id"]').prepend("<option value='' disabled selected='selected'>--Patient--</option>");
            $('select[name="product_id"]').prepend("<option value='' disabled selected='selected'>--Product--</option>");
            $('select[name="doctor_id"]').prepend("<option value='' disabled selected='selected'>--Doctor--</option>");*/
          
            $('select[name="partner_id"]').on('change', function(){

                var pid = $(this).val();
                if(pid){
                    $.ajax({
                        url: "{{ url('/getall')}}" + "/" + pid,
                        type:"get",
                        dataType : 'json',
                        success:function(data) {

                            $('select[name="patient_id"]').empty();
                            $('select[name="doctor_id"]').empty();
                            $('select[name="product_id"]').empty();
                            $.each(data, function(key, value){

                                if(key == "patient"){
                                    $.each(value, function(key, value){

                                        $('select[name="patient_id"]').append('<option value="'+ key +'">' + value + '</option>');

                                    });
                                }

                                if(key == "doctor"){
                                    $.each(value, function(key, value){

                                        $('select[name="doctor_id"]').append('<option value="'+ key +'">' + value + '</option>');

                                    });
                                }
                                if(key == "product"){
                                    $.each(value, function(key, value){

                                        $('select[name="product_id"]').append('<option value="'+ key +'">' + value + '</option>');

                                    });
                                }
                            });

                            if(!$('select[name="patient_id"]').val() ) {
                                if( !$('.newPatient').length)
                                    $('select[name="patient_id"]').after("<p class='newPatient'> You don't have added patient yet, Please <a href='{{url("patients/create")}}' > <b>    Add new Patient</b></a></p>");
                            }else {
                                $('.newPatient').hide();
                            }

                            if(!$('select[name="product_id"]').val() ) {
                                if( !$('.newProduct').length)
                                    $('select[name="product_id"]').after("<p class='newProduct'> You don't have added product yet, Please <a href='{{url("products/create")}}' ><b> Add new Product</b></a></p>");
                            }else {
                                $('.newProduct').hide();
                            }

                            if(!$('select[name="doctor_id"]').val() ) {
                                if( !$('.newDoctor').length)
                                    $('select[name="doctor_id"]').after("<p class='newDoctor'> You don't have added doctor yet, Please <a href='{{url("doctors/create")}}' ><b> Add new Doctor</b></a></p>");
                            }else {
                                $('.newDoctor').hide();
                            }

                        },
                        error: function() {
                            alert("error");
                        }
                    });

                }else {

                }
            });

        });

    </script>

@endpush
