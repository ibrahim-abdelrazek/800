<?php
/**
 * Created by PhpStorm.
 * User: NOH
 * Date: 10/12/2017
 * Time: 3:39 PM
 */

return [
    'create_partner_types' => 'Create Partner Types',
];