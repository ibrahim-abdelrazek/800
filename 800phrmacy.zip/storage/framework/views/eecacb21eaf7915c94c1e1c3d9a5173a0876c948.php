

<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, [  'class' => 'form-control' , 'required']); ?>

</div>

<!--  location -->
<div class="form-group col-sm-8 col-sm-offset-2" id='location'>
    <?php echo Form::label('location', 'Location:'); ?>

    <?php echo Form::text('location', null, [  'class' => 'form-control' , 'required']); ?>

</div>


<!--  partner type -->
<div class="form-group col-sm-8 col-sm-offset-2" >
    <?php echo Form::label('partner_type_id', 'Partner Type:'); ?>

    <?php echo Form::select('partner_type_id',  App\PartnerType::pluck('name', 'id') , null, ['class' => 'form-control' , 'required']); ?>

</div>


<!--  username -->
<div class="form-group col-sm-8 col-sm-offset-2" >
    <?php echo Form::label('username', 'Username:'); ?>

    <?php echo Form::text('username', null, [  'class' => 'form-control' , 'required']); ?>

</div>

<!--  email -->
<div class="form-group col-sm-8 col-sm-offset-2" >
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, [  'class' => 'form-control' , 'required']); ?>

</div>

<!--  password -->

<div class="form-group col-sm-8 col-sm-offset-2" >
    <?php echo Form::label('password', 'Password:'); ?>

    <?php if(isset($partner)): ?>
        <?php echo Form::password('password', ['class' => 'form-control' ]); ?>

    <?php else: ?>
        <?php echo Form::password('password', ['class' => 'form-control' , 'required']); ?>

    <?php endif; ?>
</div>

<!--  user groupid -->
<div class="form-group col-sm-8 col-sm-offset-2" >
    <?php echo Form::hidden('user_group_id', App\UserGroup::where('group_name','partner')->value('id') ); ?>

</div>
<?php echo Form::hidden('uid' ); ?>



<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('partners.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








