<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo e(asset('libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/responsejs/response.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/loading-overlay/loadingoverlay.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/tether/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jscrollpane/jquery.jscrollpane.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jscrollpane/jquery.mousewheel.js')); ?>"></script>
<script src="<?php echo e(asset('libs/flexibility/flexibility.js')); ?>"></script>
<script src="<?php echo e(asset('libs/noty/noty.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/velocity/velocity.min.js')); ?>"></script>
<!-- END PAGE LEVEL PLUGINS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo e(asset('')); ?>assets/scripts/common.min.js"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<div class="ks-mobile-overlay"></div>
<?php echo $__env->yieldPushContent('customjs'); ?>
</body>
</html>