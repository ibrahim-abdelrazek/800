<div class="table">

   <table class="table table-responsive" id="igfollows-table">
        <thead> 
        <th>prescription</th>        
        <th>insurance image</th>
        <th>insurance text</th>
        <!--<th>notes</th>-->
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->prescription); ?></td>
                <td><img src="<?php echo URL::asset('upload'.'/'.$order->insurance_image); ?>"></td>
                <td><?php echo e($order->insurance_text); ?></td>
                <!--<td><?php echo e($order->notes); ?></td>-->
                <td>
                    <?php echo Form::open(['route' => ['orders.destroy', $order->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo url('orders/'. $order->id); ?>" class='btn btn-default btn-xs'>Show</a>

                        <a href="<?php echo e(URL::to('orders/' . $order->id . '/edit')); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>