<body>
<?php if(auth()->guard()->guest()): ?>
    <?php echo $__env->yieldContent('login'); ?>
<?php else: ?>
    <body class="ks-navbar-fixed ks-sidebar-default ks-sidebar-position-fixed ks-page-header-fixed ks-theme-primary ks-page-loading">
    <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="ks-page-container">
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="ks-column ks-page">
       <!--All Pages should have these structure -->
        <!--<div class="ks-page-header">
            <section class="ks-title">
                <h3>Blank Page</h3>
            </section>
        </div>
        <div class="ks-page-content">
            <div class="ks-page-content-body">
                <div class="container-fluid">
                    Blank page content.
                </div>
            </div>
        </div>-->
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<?php endif; ?>