<div class="ks-nav-body">
    <div class="ks-nav-body-wrapper">
        <div class="container-fluid">
            <table id="guest-datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th rowspan="1" colspan="1">Hotel</th>
                    <th rowspan="1" colspan="1">Name</th>
                    <th rowspan="1" colspan="1">Officer Name</th>
                    <th rowspan="1" colspan="1">Contact Number</th>
                    <th rowspan="1" colspan="1">Guest Room Number</th>
                    <th rowspan="1" colspan="1">Special Instructions</th>
                    <th rowspan="1" colspan="1">Actions</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th rowspan="1" colspan="1">Hotel</th>
                    <th rowspan="1" colspan="1">Name</th>
                    <th rowspan="1" colspan="1">Officer Name</th>
                    <th rowspan="1" colspan="1">Contact Number</th>
                    <th rowspan="1" colspan="1">Guest Room Number</th>
                    <th rowspan="1" colspan="1">Special Instructions</th>
                    <th rowspan="1" colspan="1">Actions</th>
                </tr>
                </tfoot>
                <tbody>
                <?php $__currentLoopData = $hotelguests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelguest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $hotelguest->name; ?></td>
                        <td><?php echo $hotelguest->officer_name; ?></td>
                        <td><?php echo $hotelguest->contact_number; ?></td>
                        <td><?php echo $hotelguest->guest_room_number; ?></td>
                        <td><?php echo $hotelguest->guest_first_name; ?></td>
                        <td><?php echo $hotelguest->guest_last_name; ?></td>
                        <td><?php echo $hotelguest->items; ?></td>

                        <td>
                            <?php if($hotelguest->user_id == null): ?>
                                Null
                            <?php else: ?>
                                $hotelguest->user->getUserName;
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo Form::open(['route' => ['hotelguest.destroy', $hotelguest->id], 'method' => 'delete']); ?>

                            <div class='btn-group'>
                                <a href="<?php echo route('hotelguest.show', [$hotelguest->id]); ?>"
                                   class='btn btn-default btn-xs'>Show</a>
                                <a href="<?php echo route('hotelguest.edit', [$hotelguest->id]); ?>"
                                   class='btn btn-default btn-xs'>Edit</a>
                                <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                            </div>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('customjs'); ?>
    <script src="<?php echo e(asset('libs/datatables-net/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/media/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
    <script type="application/javascript">
        (function ($) {
            $(document).ready(function () {
                var table = $('#guest-datatable').DataTable({
                    lengthChange: false,
                    buttons: [
                        'copyHtml5',
                        'excelHtml5',
                        'csvHtml5',
                        'pdfHtml5',
                        'colvis'
                    ],
                    initComplete: function () {
                        $('.dataTables_wrapper select').select2({
                            minimumResultsForSearch: Infinity
                        });
                    }
                });

                table.buttons().container().appendTo('#guest-datatable_wrapper .col-md-6:eq(0)');
                $('#guest-datatable_filter').addClass('pull-right');
                $('#guest-datatable_paginate').addClass('pull-right');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>