
<div>
                    <?php if($errors->any()): ?>
                       <div class="alert alert-danger">
                           <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                           </ul>
                           </div>
                           <?php endif; ?>
                    </div>
<!--  first-Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('first_name', 'f_Name:'); ?>

    <?php echo Form::text('first_name', null, [  'class' => 'form-control']); ?>

</div>


<!--  last-Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('last_name', 'l_Name:'); ?>

    <?php echo Form::text('last_name', null, [  'class' => 'form-control']); ?>

</div>


<!--  date -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('date', 'date:'); ?>

    <?php echo Form::date('date',null,  [  'class' => 'form-control']); ?>

</div>

<!-- gender-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('gender', 'gender:'); ?>

    <?php echo Form::select('gender',['male' => 'male','female'=>'female' ],null, [  'class' => 'form-control']); ?>

</div>


<!--  contact_number-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('contact_number', 'contact_number:'); ?>

    <?php echo Form::text('contact_number',null, [  'class' => 'form-control']); ?>

</div>


<!--  email-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('email', 'email:'); ?>

    <?php echo Form::email('email',null, [  'class' => 'form-control']); ?>

</div>



<!-- insurance_card_details-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('insurance_card_details', 'insurance card details:'); ?>

    <?php echo Form::text('insurance_card_details',null, [  'class' => 'form-control']); ?>

</div>



<!-- emirates_id_details -->

<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('emirates_id_details', 'emirates id details:'); ?>

    <?php echo Form::text('emirates_id_details',null, [  'class' => 'form-control']); ?>

</div>



<!-- notes-->

<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('notes', 'notes:'); ?>

    <?php echo Form::textarea('notes',null, [  'class' => 'form-control']); ?>

</div>


<!-- address -->
<!-- address city-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('address city', 'city:'); ?>

    <?php echo Form::text('addresscity',null, [  'class' => 'form-control','required' => 'required']); ?>

</div>

<!-- address area-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('address area', 'area:'); ?>

    <?php echo Form::text('addressarea',null, [  'class' => 'form-control','required' => 'required']); ?>

</div>

<!-- address street-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('address street', 'street:'); ?>

    <?php echo Form::text('addressstreet',null, [  'class' => 'form-control','required' => 'required']); ?>

</div>

<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    
    office<input type="checkbox" id="checkbox1"/>
    <div id="office" style="display:none">
    <ul >
    company name<li > <?php echo Form::text('addresscompany',null, [  'id' => 'autoUpdate']); ?></li>
    
     building name<li> <?php echo Form::text('addressbuilding',null, [   'id' => 'autoUpdate2']); ?></li>
    
      office<li> <?php echo Form::text('addressoffice',null, [  'id' => 'autoUpdate3']); ?></li>
    
    <!--<?php echo Form::checkbox('check',null,[  'id' => 'checkbox1']); ?>-->
    <!--<?php echo Form::checkbox('address', null, ['id'=>'checkbox1', 'class' => 'checkbox1']); ?>-->
    </ul>
    </div>
    <div> home<input type="checkbox" name="" id="checkbox2"> 
    <div id="home" style="display:none">
    <div>
    <?php echo Form::label(' addressvilla', 'villa:'); ?>

    <input type="checkbox" name="addressvilla"  id="villa">
    <div id="villanumber" style="display:none">
    <?php echo Form::text('villanumber',null, [  'id' => '']); ?>

</div>
    
    <div>
    <?php echo Form::label(' addressapartment', 'apartment:'); ?>

    
    <input type="checkbox" name="addressapartment" id="addressapartment">
    </div>
    </div>
    </div>
    
</div>
<!--<div id="villanumber" style="display:none">
    <?php echo Form::text('villanumber',null, [  'id' => '']); ?>

</div>-->
<div id="apartment" style="display:none">
    buiding name: <?php echo Form::text('buildingname',null, [ 'id' => '']); ?><br/>
    apartment number:<?php echo Form::text('apartmentnumber',null, [  'id' => '']); ?>

</div>

    <script type="text/javascript">
     $(document).ready(function(){
$('#villa').change(function () {
      $('#villanumber').fadeToggle();
      $('#apartment').hide();
    });
});
$(document).ready(function(){
$('#addressapartment').change(function () {
      $('#apartment').fadeToggle();
      $('#villanumber').hide();
    });


});
        $(document).ready(function(){
$('#checkbox1').change(function () {
      $('#office').fadeToggle();
      $('#home').hide();
    });


});
         $(document).ready(function(){
$('#checkbox2').change(function () {
      $('#home').fadeToggle();
      $('#office').hide();
    });


});


    </script>
</div>



<!--  partner_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('partner', 'partner'); ?>

   <?php echo form :: select ('partner_id',App\Partner::pluck('name','id'),null,['class' => 'from-controller']); ?>

 
</div>



<!-- usr-id-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
<?php echo Form::hidden('user_id', Auth::user()->id ); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('patients.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








