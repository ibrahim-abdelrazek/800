


<!--  Name -->
<div class="form-group col-sm-8 col-sm-offset-2" id='name'>
    <?php echo Form::label('group_name', 'Name:'); ?>

    <?php echo Form::text('group_name', null, [  'class' => 'form-control' , 'required']); ?>

</div>



<?php

    $models = ['doctor','patient', 'hotelguest' ,'nurse','order', 'product', 'transaction'] ;
    $actions = ['view', 'add' ,'edit' ,'delete'];


?>

<div class="table text-center">
    <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>Model</th>
        <?php

        foreach ($actions  as $action ){

            echo "<th>" . $action ."</th>";
        }
        ?>
        </thead>

        <tbody>
        <?php
            foreach ($models as $model){
            echo "<tr>";
            echo "<td>".  $model. "</td>";

            foreach ($actions as $action){
                  ?>
                  <td><?php echo e(Form::checkbox( $model.$action,1)); ?>

        <?php
            }
            ?>

            <?php
                echo "</tr>";
            }

        ?>
            <tr>

            </tr>
        </tbody>
    </table>
</div>




<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('usergroups.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








