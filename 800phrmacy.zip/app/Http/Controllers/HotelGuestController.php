<?php

namespace App\Http\Controllers;

use App\HotelGuest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class HotelGuestController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
      /*  if(Auth::check()){
            dd(Auth::user()->user_group_id );

            if(Auth::user()->user_group_id == 1 ){
                $this->middleware('auth', ['only' => ['show']]);
            }
        }*/

    }



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if(Auth::user()->user_group_id == 1  ){

            $hotelguests = HotelGuest::get();

        }elseif (Auth::user()->user_group_id == 2  ) {

            $hotelguests = HotelGuest::where('partner_id',Auth::user()->partner_id)->get();

        } else{

            $hotelguests = HotelGuest::where('user_id',Auth::user()->id)->get();
        }

        return view('hotelguest.index')->with('hotelguests' , $hotelguests );

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

        return view('hotelguest.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $input = $request->all();

        $hotleguest = HotelGuest::create($input);

        return redirect(route('hotelguest.index'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $hotelguest = HotelGuest::find($id);

        if(empty($hotelguest)){
            return redirect(route('hotelguest.index'));
        }

        return view('hotelguest.show')->with('hotelguest' , $hotelguest );

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $hotelguest = HotelGuest::find($id);

        if(empty($hotelguest)){
            return redirect(route('hotelguest.index'));
        }

        return view('hotelguest.edit')->with('hotelguest' , $hotelguest );

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $hotelguest = HotelGuest::find($id);

        if(empty($hotelguest)){
            return redirect(route('hotelguest.index'));
        }

        $hotelguest->update($request->all());

        return redirect(route('hotelguest.index'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $hotelguest = HotelGuest::find($id);
        if(empty($hotelguest)){
            return redirect(route('hotelguest.index'));
        }
        $hotelguest->delete($id);
        return redirect(route('hotelguest.index'));


    }
}
