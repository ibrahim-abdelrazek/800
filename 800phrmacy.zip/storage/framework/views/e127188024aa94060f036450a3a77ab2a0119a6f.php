<div class="table">
   <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>Name</th>
        <th>Status</th>
        <th colspan="3">Action</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $partnertypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partnertype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $partnertype->name; ?></td>
                <td>
                    <?php if($partnertype->status == 1): ?>
                        Active
                    <?php else: ?>
                        Not Active
                     <?php endif; ?>
                </td>
                <td>
                    <?php echo Form::open(['route' => ['partnertypes.destroy', $partnertype->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('partnertypes.show', [$partnertype->id]); ?>" class='btn btn-default btn-xs'>Show</a>
                        <a href="<?php echo route('partnertypes.edit', [$partnertype->id]); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>