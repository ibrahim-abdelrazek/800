<div class="table text-center">
   <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>Name</th>
        <th>Officer Name</th>
        <th>Contact Number</th>
        <th>Guest Room Number</th>
        <th>Guest First Name</th>
        <th>Guest Last Name</th>
        <th>Items</th>
        <th>User</th>
        <th colspan="3">Action</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $hotelguests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelguest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $hotelguest->name; ?></td>
                <td><?php echo $hotelguest->officer_name; ?></td>
                <td><?php echo $hotelguest->contact_number; ?></td>
                <td><?php echo $hotelguest->guest_room_number; ?></td>
                <td><?php echo $hotelguest->guest_first_name; ?></td>
                <td><?php echo $hotelguest->guest_last_name; ?></td>
                <td><?php echo $hotelguest->items; ?></td>

                <td>
                    <?php if($hotelguest->user_id == null): ?>
                        Null
                    <?php else: ?>
                        $hotelguest->user->getUserName;
                     <?php endif; ?>
                </td>
                <td>
                    <?php echo Form::open(['route' => ['hotelguest.destroy', $hotelguest->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('hotelguest.show', [$hotelguest->id]); ?>" class='btn btn-default btn-xs'>Show</a>
                        <a href="<?php echo route('hotelguest.edit', [$hotelguest->id]); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>