@include('layouts.head')
@include('layouts.main')
@include('layouts.footer')