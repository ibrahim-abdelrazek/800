<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    static $model = 'User';

    protected $fillable = [
        'id',
        'username',
        'email',
        'password',
        'name',
        'user_group_id',
        'partner_id'
    ];


    

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];


    public function userGroup(){

         return $this->belongsTo( UserGroup::class);

    }

    public function messages(){

        return $this->hasMany( Message::class);

    }

    public function isAdmin(){
        return (bool) $this->usergroup->id == 1;
    }






}
