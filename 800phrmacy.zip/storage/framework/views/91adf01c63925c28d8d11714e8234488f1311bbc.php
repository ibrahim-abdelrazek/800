<div class="table text-center">
   <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>Name</th>

        <th colspan="3">Action</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $usergroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usergroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $data = unserialize($usergroup->action);

            ?>
            <tr>
                <td><?php echo $usergroup->group_name; ?></td>

                <td>
                    <?php echo Form::open(['route' => ['usergroups.destroy', $usergroup->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('usergroups.show', [$usergroup->id]); ?>" class='btn btn-default btn-xs'>Show Details</a>
                        <a href="<?php echo route('usergroups.edit', [$usergroup->id]); ?>" class='btn btn-default btn-xs'>Edit</a>
                            <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure? if delete this , all related users will delete also')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>