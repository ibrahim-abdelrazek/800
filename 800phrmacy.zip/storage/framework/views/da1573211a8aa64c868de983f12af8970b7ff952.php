<table class="table table-bordered text-light stacktable large-only">
    <thead class="thead-default">
    <tr>
        <th width="1">#</th>
        <th>Name</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php ($i = 1); ?>
    <?php $__currentLoopData = $usergroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usergroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo $usergroup->group_name; ?></td>

            <td>
                <div class='btn-group'>
                    <button data-id="<?php echo e($usergroup->id); ?>"
                            class='btn btn-default show-details btn-xs'>Details</button>
                    <a href="<?php echo route('usergroups.edit', [$usergroup->id]); ?>" class='btn btn-default btn-xs'>Edit</a>
                    <?php echo Form::open(['route' => ['usergroups.destroy', $usergroup->id], 'method' => 'delete']); ?>

                    <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure? if delete this , all related users will delete also')"]); ?>

                    <?php echo Form::close(); ?>


                </div>
            </td>
        </tr>
        <?php ($i++); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>