<div class="table">

   <table class="table table-responsive" id="igfollows-table">
        <thead> 
        <th>prescription</th>        
        <th>insurance image</th>
        <th>insurance text</th>
        <th>product</th>
        <th>doctor</th>
        <th>patient</th>
        <th>notes</th>
        </thead>
        <tbody>
        @foreach($orders as $order)
            <tr>
                <td>{{ $order->prescription }}</td>
                <td><img src="{!! URL::asset('upload'.'/'.$order->insurance_image) !!}"></td>
                <td>{{ $order->product->name }}</td>
                <td>{{ $order->doctor->name}}</td>
                <td>{{ $order->product->patient }}</td>
                <td>{{ $order->notes }}</td>
                <td>
                    {!! Form::open(['route' => ['orders.destroy', $order->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{!! url('orders/'. $order->id) !!}" class='btn btn-default btn-xs'>Show</a>

                        <a href="{{ URL::to('orders/' . $order->id . '/edit') }}" class='btn btn-default btn-xs'>Edit</a>
                        {!! Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

</div>