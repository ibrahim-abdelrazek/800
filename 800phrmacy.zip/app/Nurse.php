<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nurse extends Model
{
    static $model = 'Nurse';
    protected $fillable = [
        'id',
         'name',
         'partner_id',
         'user_id'
    ];
    public function partener (){
    	return $this->belongsTo(Partner::class);
    }
}
