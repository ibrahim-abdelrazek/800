<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Nurse;
use Illuminate\Support\Facades\Auth;


class NurseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function __construct()
    {
        $this->middleware('auth');

    }

    public function index()
    {
        //
         if(Auth::user()->user_group_id == 1 ){

         $nurses = Nurse::get();

         }elseif (Auth::user()->user_group_id == 2 ) {

         $nurses = Nurse::where('partner_id',Auth::user()->partner_id)->get();

         } else{

         $nurses = Nurse::where('user_id',Auth::user()->id)->get();
         }


        return view('nurses.index')->with('nurses' , $nurses );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('nurses.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
        'name' => 'required|max:45',
        'partner_id'=>'required'
        ]); 
         $input = $request->all();

        $nurses = Nurse::create($input);


        return redirect(route('nurses.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $nurse = Nurse::find($id);

        if(empty($nurse)){
            return redirect(route('nurses.index'));
        }

        return view('nurses.show')->with('nurse' , $nurse );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $nurse = Nurse::find($id);

        if(empty($nurse)){
            return redirect(route('nurses.index'));
        }

        return view('nurses.edit')->with('nurse' , $nurse );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
        'name' => 'required|max:45']); 
        
        $nurse = Nurse::find($id);

        if(empty($nurse)){
            return redirect(route('nurses.index'));
        }

        $nurse->update($request->all());

        return redirect(route('nurses.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $nurse = Nurse::find($id);
        if(empty($nurse)){
            return redirect(route('nurses.index'));
        }
        $nurse->delete($id);
        return redirect(route('nurses.index'));
    }
}
