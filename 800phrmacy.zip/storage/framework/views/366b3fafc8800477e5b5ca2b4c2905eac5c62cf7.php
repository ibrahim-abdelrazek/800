<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 > My Profile  </h3>

                        <a href="<?php echo route('profile.edit', [$profile['id']]); ?> " class="pull-right btn btn-default create"> Edit Profile</a>
                    </div>

                    <div class="panel-body">

                        <div class="show">
                            <span>Name: </span>
                            <span class="value" ><?php echo $profile['name']; ?></span>
                        </div>
                        <br>

                        <div class="show">
                            <span>Username: </span>
                            <span class="value" ><?php echo $profile['username']; ?></span>
                        </div>
                        <br>
                        <div class="show">
                            <span>Email: </span>
                            <span class="value" ><?php echo $profile['email']; ?></span>
                        </div>
                        <br>

                        <?php if(isset($profile['location'])): ?>

                            <div class="show">
                                <span>Location: </span>
                                <span class="value" ><?php echo $profile['location']; ?></span>
                            </div>
                            <br>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>