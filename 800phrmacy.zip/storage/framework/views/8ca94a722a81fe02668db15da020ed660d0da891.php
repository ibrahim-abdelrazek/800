<!--  Name -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('name', 'Name:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::text('name', null, [  'placeholder'=>'Enter Partner\'s name', 'class' => 'form-control']); ?>

    </div>
</div>
<!--  username -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('username', 'Username:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::text('username', null, [  'class' => 'form-control']); ?>

    </div>
</div>
<!--  Email -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('email', 'email:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::email('email', null, [  'class' => 'form-control']); ?>

    </div>
</div>
<!--  password -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('password', 'Password:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::password('password',[  'class' => 'form-control']); ?>

    </div>
</div>

<!--  Status -->
<div class="form-group row">
    <label for="default-input"
           class="col-sm-2 form-control-label"><?php echo Form::label('user_group_id', 'Sub-Users:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::select('user_group_id', \App\UserGroup::where('partner_id',Auth::user()->partner_id)->pluck('group_name','id'), null, [  'class' => 'form-control']); ?>

    </div>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('users.index'); ?> " class="btn btn-default"> Cancel</a>
</div>








