<div class="ks-nav-body">
    <div class="ks-nav-body-wrapper">
        <div class="container-fluid">
            <table id="user-datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th rowspan="1" colspan="1">Name</th>
                    <th rowspan="1" colspan="1">Contact No.</th>
                    <th rowspan="1" colspan="1">Email</th>
                    <th rowspan="1" colspan="1">Notes</th>
                    <th rowspan="1" colspan="1">Actions</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th rowspan="1" colspan="1">Name</th>
                    <th rowspan="1" colspan="1">Contact No.</th>
                    <th rowspan="1" colspan="1">Email</th>
                    <th rowspan="1" colspan="1">Notes</th>
                    <th rowspan="1" colspan="1">Actions</th>
                </tr>
                </tfoot>
                <tbody>
                <?php ($i=1); ?>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($patient->first_name . $patient->last_name); ?></td>
                <td><?php echo e($patient->contact_number); ?></td>
                <td><?php echo e($patient->email); ?></td>
                <td><?php echo e($patient->notes); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['patients.destroy', $patient->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo url('patients/'. $patient->id); ?>" class='btn btn-default btn-xs'>Show</a>

                        <a href="<?php echo e(URL::to('patients/' . $patient->id . '/edit')); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php ($i++); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
   </table>
</div>
</div>
</div>

<?php $__env->startPush('customjs'); ?>
    <script src="<?php echo e(asset('libs/datatables-net/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/media/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables-net/extensions/buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
    <script type="application/javascript">
        (function ($) {
            $(document).ready(function () {
                var table = $('#user-datatable').DataTable({
                    lengthChange: false,
                    buttons: [
                        'copyHtml5',
                        'excelHtml5',
                        'csvHtml5',
                        'pdfHtml5',
                        'colvis'
                    ],
                    initComplete: function () {
                        $('.dataTables_wrapper select').select2({
                            minimumResultsForSearch: Infinity
                        });
                    }
                });

                table.buttons().container().appendTo('#user-datatable_wrapper .col-md-6:eq(0)');
                $('#user-datatable_filter').addClass('pull-right');
                $('#user-datatable_paginate').addClass('pull-right');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>