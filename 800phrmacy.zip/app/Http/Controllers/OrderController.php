<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use Illuminate\Support\Facades\Auth;




class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function __construct()
    {
        $this->middleware('auth');

    }

    public function index()
    {
        //
        if(Auth::user()->user_group_id == 1 ){

         $orders = Order::get();

         }elseif (Auth::user()->user_group_id == 2 ) {

         $orders = Order::where('partner_id',Auth::user()->partner_id)->get();

         } else{

         $orders = Order::where('user_id',Auth::user()->id)->get();
         }

        return view('orders.index')->with('orders' , $orders );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('orders.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
         $this->validate($request, [
        'prescription' => 'required|min:3',
        'insurance_image' => 'required',
        'insurance_text' => 'required',
        'notes' => 'required|min:5',
        'patient_id' => 'required',
        'doctor_id' => 'required',
        'partner_id' => 'required',
        'product_id' => 'required']);



         
       

        $input = $request->all();
          
           

            // upload image
            $destinationPath = './upload/';
            $file = $request->file('insurance_image');

            $input['insurance_image'] = $file->getClientOriginalName();
                //$input['insurance_image']  =  rand(0,10000000)  . '_' .$input['insurance_image'] ;
                $file->move($destinationPath,$file->getClientOriginalName());
            
        

        $orders = Order::create($input);
         
        return redirect(route('orders.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $order = Order::find($id);

        if(empty($order)){
            return redirect(route('orders.index'));
        }

        return view('orders.show')->with('order' , $order );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $order = Order::find($id);

        if(empty($order)){
            return redirect(route('orders.index'));
        }

        return view('orders.edit')->with('order' , $order );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //|image|mimes:jpeg,png,jpg,gif,svg|max:2048
        $this->validate($request, [
        'prescription' => 'required|min:3',
        'insurance_image' => '',
        'insurance_text' => 'required',
        'notes' => 'required|min:5',
        'patient_id' => 'required',
        'doctor_id' => 'required',
        'partner_id' => 'required',
        'product_id' => 'required']);

        $order = Order::find($id);

        if(empty($order)){
            return redirect(route('orders.index'));
        }
         $input = $request->all();
          
          /* $image= $request->file('insurance_image');
         if($image == null)
         {
            $input['insurance_image']=;
         }*/
          

            // upload image
            $destinationPath = './upload/';
            $file = $request->file('insurance_image');

            $input['insurance_image'] = $file->getClientOriginalName();
                //$input['insurance_image']  =  rand(0,10000000)  . '_' .$input['insurance_image'] ;
                $file->move($destinationPath,$file->getClientOriginalName());

        $order->update($input);

        return redirect(route('orders.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $order = Order::find($id);
        if(empty($order)){
            return redirect(route('orders.index'));
        }
        $order->delete($id);
        return redirect(route('orders.index'));
    }
}
