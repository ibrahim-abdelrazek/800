<div class="table text-center">
   <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>Name</th>
        <th>Username</th>
        <th>Email</th>
        <th>Sub-User</th>
        <th colspan="3">Action</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $user->name; ?></td>
                <td><?php echo $user->username; ?></td>
                <td><?php echo $user->email; ?></td>
                <td><?php echo $user->userGroup->group_name; ?></td>

                <td>
                    <?php echo Form::open(['route' => ['users.destroy', $user->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('users.show', [$user->id]); ?>" class='btn btn-default btn-xs'>Show</a>
                        <a href="<?php echo route('users.edit', [$user->id]); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>