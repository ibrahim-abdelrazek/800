<div class="row">
    <div class="col-lg-12 ks-panels-column-section">
        <div class="card">
            <div class="card-block">
                <h5 class="card-title">Create new Doctor</h5>
                <?php echo Form::open(['route' => 'doctors.store']); ?>


                <?php echo $__env->make('doctors.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>

    </div>
</div>