<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<!-- BEGIN HEAD -->
<head>
    <meta charset="UTF-8">
    <title>800 Pharmacy</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('libs/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/fonts/line-awesome/css/line-awesome.min.css')); ?>">
    <!--<link rel="stylesheet" type="text/css" href="assets/fonts/open-sans/styles.css">-->

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/fonts/montserrat/styles.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('libs/tether/css/tether.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('libs/jscrollpane/jquery.jscrollpane.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('libs/flag-icon-css/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/common.min.css')); ?>">
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN THEME STYLES -->
    <?php if(auth()->guard()->guest()): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/pages/auth.min.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/themes/primary.min.css')); ?>">

    <?php endif; ?>
    <link class="ks-sidebar-dark-style" rel="stylesheet" type="text/css"
                  href="<?php echo e(asset('assets/styles/themes/sidebar-black.min.css')); ?>">
            <!-- END THEME STYLES -->
            <?php echo $__env->yieldPushContent('customcss'); ?>
</head>

<!-- END HEAD -->
