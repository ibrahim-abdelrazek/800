<?php

namespace App\Http\Controllers;

use App\Http\Requests\PartnerRequest;
use App\Partner;
use App\User;

use Illuminate\Http\Request;

class PartnersController extends Controller
{

    public function __construct()
    {

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $partners = Partner::all();

        return view("partners.index")->with('partners',$partners);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('partners.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'name' => 'required',
            'location' => 'required',
            'partner_type_id' => 'required',
            'username' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
        ]);



        $partners = Partner::create([
            'name' => request('name'),
            'location' => request('location'),
            'partner_type_id' => request('partner_type_id')
        ]);

        $users = User::create([
            'name' => request('name'),
            'username' => request('username'),
            'email' => request('email'),
            'password' => bcrypt(request('password')),
            'user_group_id' => 2,
            'partner_id'=> $partners->id
        ]);

        return redirect( route('partners.index'));


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $partner = Partner::find($id);

        //$partnerUser = $partner->user; //to merge between 2 tables partner and users

        if(empty($partner)){

            return redirect( route('partners.index'));
        }

        return view('partners.show')->with('partner',$partner);


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $partner = Partner::where('id',$id)->first();

        $user =User::where('partner_id',$id)->first();
        $p = collect([
            'id'=> $partner['id'],
            'name'=> $partner['name'],
            'location'=> $partner['location'] ,
            'partner_type'=> $partner->partnerType->name,
            'username'=> $user['username'],
            'email'=> $user['email'],
            'uid' => $user['id']
            ]);

        // dd($p);
        //$p =$partner->merge($user);
         // $p->id = $partner->id;


        if(empty($partner)){

            return redirect(route("partners.index"));
        }


        //$user->id = $id;
       // dd($user);

        return view('partners.edit')->with("partner",$p);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $request->validate([
            'name' => 'required',
            'location' => 'required',
            'partner_type_id' => 'required',
            'username' => 'required',
            'email' => 'required|unique:users,email,'.User::where('id',$request->uid)->value('id')
        ]);

        Partner::where('id', $id)->update(array(
            'name' => request('name'),
            'location' => request('location'),
            'partner_type_id' => request('partner_type_id')
            ));

        if(isset($request->password)){
            User::where('id',$request->uid)->update(array(
                'name' => request('name'),
                'username' => request('username'),
                'email' => request('email'),
                'password' => bcrypt(request('password')),
                'user_group_id' => request('user_group_id'),
            ));
        } else{
            User::where('id',$request->uid)->update(array(
                'name' => request('name'),
                'username' => request('username'),
                'email' => request('email'),
                'user_group_id' => request('user_group_id'),
            ));
        }



        return redirect(route("partners.index"));


    }

    // to delete  all data of user
    protected function deleteModel($model,$id){

        $ids = $model::where('user_id',$id)->select("id")->get();
        $del = $model::whereIn('id', $ids)->delete();

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $partner = Partner::find($id);

        $user = User::where('partner_id',$id);

        if(empty($partner)){

            return redirect(route("partners.index"));
        }



        $partner->delete($id);
        $user->delete($id);

        return redirect(route("partners.index"));


    }
}
