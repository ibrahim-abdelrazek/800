<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class=""> Partner Type </h3>
                    </div>

                    <div class="panel-body">

                        <div class="show">
                            <span>Name: </span>
                            <span class="value" ><?php echo $user->name; ?></span>
                        </div>

                        <div class="show">
                            <span>Username: </span>
                            <span class="value" ><?php echo $user->username; ?></span>
                        </div>
                        <div class="show">
                            <span>email: </span>
                            <span class="value" ><?php echo $user->email; ?></span>
                        </div>

                        <div class="show">
                            <span>Sub-User: </span>
                            <span class="value" ><?php echo $user->UserGroup->group_name; ?></span>
                        </div>

                        <br>
                        <a href="<?php echo route('users.index'); ?>" class="btn btn-default pull-right">Back</a>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>