<div class="table">

   <table class="table table-responsive" id="igfollows-table">
        <thead>
        <th>Name</th>
        <th>image</th>        
        <th>price</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->name); ?></td>
                <td><img src="<?php echo URL::asset('upload'.'/'.$product->image); ?>"></td>
                <td><?php echo e($product->price); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['products.destroy', $product->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo url('products/'. $product->id); ?>" class='btn btn-default btn-xs'>Show</a>

                        <a href="<?php echo e(URL::to('products/' . $product->id . '/edit')); ?>" class='btn btn-default btn-xs'>Edit</a>
                        <?php echo Form::button('Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>