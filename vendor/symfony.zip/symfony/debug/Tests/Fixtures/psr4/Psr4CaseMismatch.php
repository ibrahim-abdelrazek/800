<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

class PSR4CaseMismatch
{
}
