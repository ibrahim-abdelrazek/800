

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3> Edit Partner Types </h3>
                    </div>

                    <div class="panel-body">

                        <?php echo Form::model($profile, ['route' => ['profile.update', $profile['id']], 'method' => 'patch']); ?>


                        <!--  Name -->
                            <div class="form-group col-sm-8 col-sm-offset-2" id='name'>
                                <?php echo Form::label('name', 'Name:'); ?>

                                <?php echo Form::text('name', null, [  'class' => 'form-control' , 'required']); ?>

                            </div>

                            <!--  Username -->
                            <div class="form-group col-sm-8 col-sm-offset-2" >
                                <?php echo Form::label('username', 'Username:'); ?>

                                <?php echo Form::text('username', null, [  'class' => 'form-control' , 'required']); ?>

                            </div>

                            <!--  Email -->
                            <div class="form-group col-sm-8 col-sm-offset-2" >
                                <?php echo Form::label('email', 'Email:'); ?>

                                <?php echo Form::email('email', null, [  'class' => 'form-control' , 'required']); ?>

                            </div>
                            <!--  password -->
                            <div class="form-group col-sm-8 col-sm-offset-2" >
                                <?php echo Form::label('password', 'password:'); ?>

                                <?php echo Form::password('password', [  'class' => 'form-control' ]); ?>

                            </div>

                        <?php if(isset($profile['location'])): ?>
                            <!--  location -->
                                <div class="form-group col-sm-8 col-sm-offset-2" >
                                    <?php echo Form::label('location', 'Location:'); ?>

                                    <?php echo Form::text('location', null, [  'class' => 'form-control' ]); ?>

                                </div>
                        <?php endif; ?>

                        <?php echo Form::hidden('partner_id', null ); ?>






                            <!-- Submit Field -->
                            <div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

                                <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

                                <a href="<?php echo route('profile.index'); ?> " class="btn btn-default" > Cancel</a>
                            </div>


                            <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>