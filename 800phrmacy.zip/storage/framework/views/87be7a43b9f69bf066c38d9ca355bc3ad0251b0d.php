<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
<?php endif; ?>

<!--  Name -->
<div class="form-group row">
    <label for="default-input" class="col-sm-2 form-control-label"><?php echo Form::label('name', 'Name:'); ?></label>
    <div class="col-sm-10">
        <?php echo Form::text('name', null, [  'class' => 'form-control']); ?>

    </div>
</div>

<?php if(Auth::user()->isAdmin()): ?>
    <!--  partner_id -->
    <div class="form-group row">
        <label for="default-input"
               class="col-sm-2 form-control-label"><?php echo Form::label('partner_id', 'Partner:'); ?></label>
        <div class="col-sm-10">
            <?php echo form :: select ('partner_id',App\Partner::pluck('name','id'),null,['class' => 'form-control']); ?>

        </div>
    </div>
<?php endif; ?>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-success']); ?>

</div>








