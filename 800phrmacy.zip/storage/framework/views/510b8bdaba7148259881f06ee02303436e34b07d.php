<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class=""> <?php echo $usergroup->group_name; ?></h3>
            </div>

            <div class="panel-body">


                <?php
                    $data = unserialize($usergroup->action);
                    $models = [
                        \App\Doctor::$model,
                        \App\Patient::$model,
                        \App\HotelGuest::$model,
                        \App\Nurse::$model,
                        \App\Order::$model,
                        \App\Product::$model,
                        \App\Transaction::$model
                        ] ;
                    $actions = ['view', 'add' ,'edit' ,'delete'];
                    $dataa =array();
                    foreach ($data as $k => $v){
                        $result = str_split($v);
                        $action= array();
                        $action[$actions[0]]= $result[0];
                        $action[$actions[1]]= $result[1];
                        $action[$actions[2]]= $result[2];
                        $action[$actions[3]]= $result[3];

                        $dataa[$k] = $action;

                     }

                ?>

                <div class="table text-center">
                    <table class="table table-responsive">
                        <thead>
                        <th>Model</th>
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($action); ?></th>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $dataa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($k); ?></td>

                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($d == 1 ): ?>
                                        <td><span style="color:darkgreen">&#10004</span></td>
                                    <?php else: ?>
                                        <td><span style="color:darkred"> &#10006 </span></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                        </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>