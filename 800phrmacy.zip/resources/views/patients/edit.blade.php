@extends('layouts.app')

@section('content')
    <div class="ks-page-header">
        <section class="ks-title">
            <h3>Edit Patient {{ $patient->name }}</h3>
        </section>
    </div>
    <div class="ks-page-content">
        <div class="ks-page-content-body">
            {!! Form::model($patient, ['route' => ['patients.update', $patient->id], 'method' => 'patch']) !!}

            @include('patients.fields')

            {!! Form::close() !!}
        </div>
    </div>

@endsection

