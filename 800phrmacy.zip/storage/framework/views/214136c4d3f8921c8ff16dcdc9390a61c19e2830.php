

<?php echo Form::file('image'); ?>




<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('hotelguest.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








