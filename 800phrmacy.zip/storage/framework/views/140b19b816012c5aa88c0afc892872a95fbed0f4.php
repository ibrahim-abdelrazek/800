
<div>
                    <?php if($errors->any()): ?>
                       <div class="alert alert-danger">
                           <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                           </ul>
                           </div>
                           <?php endif; ?>
                    </div>
<!--  prescription -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('prescription', 'prescription:'); ?>

    <?php echo Form::text('prescription', null, [  'class' => 'form-control']); ?>

</div>


<!--  insurance_image -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('insurance_image', 'insurance image:'); ?>

    <?php echo Form::file('insurance_image',null,  [  'class' => 'form-control']); ?>

</div>



<!--  insurance_text -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('insurance_text', 'insurance text:'); ?>

    <?php echo Form::text('insurance_text',null, [  'class' => 'form-control']); ?>

</div>


<!-- notes -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('notest', 'notes:'); ?>

    <?php echo Form::textarea('notes',null, [  'class' => 'form-control']); ?>

</div>


<!--  patient_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('patient', 'patient'); ?>

   <?php echo form :: select ('patient_id',App\Patient::select(DB::raw("CONCAT(first_name,' ', last_name) AS full_name, id"))->pluck('full_name','id'),null,['class' => 'from-controller']); ?>

 
</div>


<!--  doctor_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('doctor', 'doctor'); ?>

   <?php echo form :: select ('doctor_id',App\Doctor::pluck('name','id'),null,['class' => 'from-controller']); ?>

 
</div>



<!--  partner_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('partner', 'partner'); ?>

   <?php echo form :: select ('partner_id',App\Partner::pluck('name','id'),null,['class' => 'from-controller']); ?>

 
</div>


<!--  product_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    <?php echo Form::label('product', 'product'); ?>

   <?php echo form :: select ('product_id',App\Product::pluck('name','id'),null,['class' => 'from-controller']); ?>

 
</div>





<!-- user-id-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
<?php echo Form::hidden('user_id', Auth::user()->id ); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    <?php echo Form::submit('Save', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo route('orders.index'); ?> " class="btn btn-default" > Cancel</a>
</div>








