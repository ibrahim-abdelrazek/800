
<div>
                    @if($errors->any())
                       <div class="alert alert-danger">
                           <ul>
                            @foreach($errors->all() as $error)
                            <li>{{$error}}</li>
                            @endforeach

                           </ul>
                           </div>
                           @endif
                    </div>
<!--  prescription -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('prescription', 'prescription:') !!}
    {!! Form::text('prescription', null, [  'class' => 'form-control']) !!}
</div>


<!--  insurance_image -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('insurance_image', 'insurance image:') !!}
    {!! Form::file('insurance_image', [  'class' => 'form-control' , 'accept' => 'image/*;capture=camera']) !!}
</div>



<!--  insurance_text -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('insurance_text', 'insurance text:') !!}
    {!! Form::text('insurance_text',null, [  'class' => 'form-control']) !!}
</div>


<!-- notes -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('notest', 'notes:') !!}
    {!! Form::textarea('notes',null, [  'class' => 'form-control']) !!}
</div>

<!--  partner_id -->
@if(Auth::user()->isAdmin())
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('partner', 'partner') !!}
    {!! Form :: select ('partner_id',App\Partner::pluck('name','id'),null,[ 'class' => 'form-control'])!!}

</div>
@endif

<!--  patient_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('patient', 'patient') !!}
    @if(Auth::user()->isAdmin())
        @if(isset($order))
            {!! Form:: select("patient_id" , \App\Patient::where("partner_id", $order->partner_id)->pluck("first_name","id"), null,[ 'class' => 'patient form-control']) !!}
        @else
            {!! Form:: select("patient_id" , [] , null,[ 'class' => 'form-control patient'])!!}

        @endif
    @else
        {!! Form :: select ('patient_id',App\Patient::select(DB::raw("CONCAT(first_name,' ', last_name) AS full_name, id"))->where("partner_id", Auth::user()->partner_id)->pluck('full_name','id'),null,[  'class' => 'form-control patient'])!!}
    @endif

</div>

<!--  doctor_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('doctor_id', 'Doctor') !!}
    @if(Auth::user()->isAdmin())
        @if(isset($order))
            {!! Form:: select("doctor_id" , \App\Doctor::where("partner_id", $order->partner_id)->pluck('name','id'), null,[ 'class' => 'doctor s1 form-control']) !!}
        @else
            {!! Form:: select("doctor_id" , [] , null,[ 'class' => 'form-control s2 doctor'])!!}

        @endif
    @else
        {!! Form :: select ('doctor_id',App\Doctor::where("partner_id", Auth::user()->partner_id)->pluck('name','id'),null,[ ' s3 doctor class' => 'form-control'])!!}
    @endif

</div>



<!--  product_id -->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
    {!! Form::label('product_id', 'Product') !!}
    @if(Auth::user()->isAdmin())
        @if(isset($order))
            {!! Form:: select("product_id" , \App\Product::where("partner_id", $order->partner_id)->pluck('name','id'), null,[ 'class' => 'product form-control']) !!}
        @else
            {!! Form:: select("product_id" , [] , null,[ 'class' => 'form-control product '])!!}

        @endif
    @else
        {!! Form :: select ('product_id',App\Product::where("partner_id", Auth::user()->partner_id)->pluck('name','id'),null,[ 'product class' => 'form-control'])!!}
    @endif

</div>









<!-- user-id-->
<div class="form-group col-sm-8 col-sm-offset-2" id=''>
{!! Form::hidden('user_id', Auth::user()->id ) !!}
</div>

<!-- Submit Field -->
<div class="form-group col-sm-8 col-sm-offset-2" id='submit'>

    {!! Form::submit('Save', ['class' => 'btn btn-danger']) !!}
    <a href="{!! route('orders.index') !!} " class="btn btn-default" > Cancel</a>
</div>








